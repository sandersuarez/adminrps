create definer = root@localhost trigger triggerupdateorder
    before update
    on orders
    for each row
BEGIN
			IF EXISTS (
            SELECT codorder
				FROM orders_sold
				WHERE codorder = OLD.codorder
			) AND (USER() = 'adminrps@127.0.0.1') THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'An order cannot be updated if it is sold';
			END IF;
        END;

