create definer = root@localhost trigger triggerupdatedraft
    before update
    on drafts
    for each row
BEGIN
			IF ((NEW.namecustomertmp IS NOT NULL OR NEW.telcustomertmp IS NOT NULL) AND NEW.codcustomer IS NOT NULL) THEN
				SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'An order cannot have both a customer name and customer phone number and a customer code ';
            END IF;
        END;

