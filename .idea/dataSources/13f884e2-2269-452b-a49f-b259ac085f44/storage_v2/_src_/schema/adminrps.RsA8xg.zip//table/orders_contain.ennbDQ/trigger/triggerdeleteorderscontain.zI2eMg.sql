create definer = root@localhost trigger triggerdeleteorderscontain
    before delete
    on orders_contain
    for each row
BEGIN
			IF EXISTS (
            SELECT codorder
				FROM orders_sold
				WHERE codorder = OLD.codorder
			) AND (USER() = 'adminrpsuser@127.0.0.1') THEN
				SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'An order cannot be deleted if it is sold';
            END IF;
        END;

