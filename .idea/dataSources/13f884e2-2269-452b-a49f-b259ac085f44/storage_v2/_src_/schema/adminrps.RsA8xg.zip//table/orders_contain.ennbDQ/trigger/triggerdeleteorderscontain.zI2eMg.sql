CREATE DEFINER = root@localhost TRIGGER triggerdeleteorderscontain
    BEFORE DELETE
    ON orders_contain
    FOR EACH ROW
BEGIN
			IF EXISTS (
            SELECT codorder
				FROM orders_sold
				WHERE codorder = OLD.codorder
			) AND (USER() = 'adminrpsuser@127.0.0.1') THEN
				SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'An order cannot be deleted if it is sold';
            END IF;
        END;

